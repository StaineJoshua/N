# AD9361 RSSI Gain Step Calibration — RTL (Verilog)

## File Structure

| File | Description |
|---|---|
| `ad9361_rssi_gain_cal.v` | **Main calibration FSM** — sweeps LO × gain, builds correction LUT |
| `rssi_accumulator.v` | RSSI hardware averager (configurable N-sample accumulate + shift divide) |
| `lo_freq_decoder.v` | LO index → MHz + AD9361 PLL word ROM |
| `rssi_correction_apply.v` | Runtime correction module — applies LUT to live RSSI, 2-cycle latency |
| `ad9361_rssi_cal_top.v` | **Top-level wrapper** integrating all submodules |
| `tb_ad9361_rssi_cal.v` | Self-checking testbench with FSM monitor + LUT verification |

## Parameters (all at top of each file)

| Parameter | Default | Description |
|---|---|---|
| `NUM_LO` | 11 | LO calibration points (4000–6000 MHz, 200 MHz step) |
| `NUM_GAIN` | 73 | Gain table entries (0..72) |
| `LO_START` | 4000 | LO sweep start [MHz] |
| `LO_STEP` | 200 | LO step size [MHz] |
| `AVG_COUNT` | 32 | RSSI hardware averages per measurement point |
| `RSSI_WIDTH` | 12 | RSSI register width (Q10.2 format, 0.25 dB LSB) |
| `CORR_WIDTH` | 8 | Correction LUT entry width (int8, ±127 × 0.25 dB) |

## Simulation

```bash
# Icarus Verilog
iverilog -o sim_out ad9361_rssi_gain_cal.v rssi_accumulator.v \
         lo_freq_decoder.v rssi_correction_apply.v tb_ad9361_rssi_cal.v
vvp sim_out
gtkwave ad9361_rssi_cal.vcd

# ModelSim
vlog *.v
vsim tb_ad9361_rssi_cal -do "run -all"
```

## Fixed-Point Convention

- RSSI values: **Q10.2** — 12-bit unsigned, 1 LSB = 0.25 dB
- Gain error: **Q10.2 signed** — extended by 2 bits for subtraction
- Correction LUT: **int8** — values in 0.25 dB LSB units, range ±31.75 dB

## FSM State Sequence

```
IDLE → INIT → SET_LO → WAIT_LO → SET_GAIN → WAIT_GAIN
     → TRIG_RSSI → WAIT_RSSI → STORE_RSSI → NEXT_GAIN (loop 73×)
     → NEXT_LO (loop 11×) → COMPUTE → WRITE_LUT → DONE
```
Total sweep: 11 LO × 73 gain × (SPI_lat + RSSI_lat) cycles ≈ 803 measurements
